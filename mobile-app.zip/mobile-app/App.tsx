/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */
import 'react-native-gesture-handler';
import React, {useEffect} from 'react';
import {
  SafeAreaView,
  StyleSheet,
  ScrollView,
  View,
  Text,
  StatusBar,
} from 'react-native';

import {
  Header,
  LearnMoreLinks,
  Colors,
  DebugInstructions,
  ReloadInstructions,
} from 'react-native/Libraries/NewAppScreen';

import SplashScreen from 'react-native-splash-screen';

import { NavigationContainer } from '@react-navigation/native';

import { AppContainer } from './src/app/components/nav-components/app.container';
import { $navigate, navigationRef, isMountedRef } from './src/app/services/navigation.service'

const checkUser = () => {
 
    // db.auth().onAuthStateChanged(user => {
      console.log('login check auth value: ');
      let isAuthenticated;
      //if (user === null || user === undefined) {
          //userId = '';
          console.log('login check auth value: ', true);
          $navigate('News')
      // }
      // else {
      //     console.log('login check auth value: ', false);
      //     //userId = user.uid;
      //     $navigate('News')
      // }
    // });
}


const App = () => {
  useEffect(() => {
    // checkUser;
    //isMountedRef.current = true;
    console.log('login check auth value: ', true);
    SplashScreen.hide();
  }, []);


  console.log('Entry point.')
  return (
    <NavigationContainer ref={navigationRef}>
      <AppContainer />
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  scrollView: {
    backgroundColor: Colors.lighter,
  },
  engine: {
    position: 'absolute',
    right: 0,
  },
  body: {
    backgroundColor: Colors.white,
  },
  sectionContainer: {
    marginTop: 32,
    paddingHorizontal: 24,
  },
  sectionTitle: {
    fontSize: 24,
    fontWeight: '600',
    color: Colors.black,
  },
  sectionDescription: {
    marginTop: 8,
    fontSize: 18,
    fontWeight: '400',
    color: Colors.dark,
  },
  highlight: {
    fontWeight: '700',
  },
  footer: {
    color: Colors.dark,
    fontSize: 12,
    fontWeight: '600',
    padding: 4,
    paddingRight: 12,
    textAlign: 'right',
  },
  postButton: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: '#ee6e73',
    position: 'absolute',
  }
});



export default App;
