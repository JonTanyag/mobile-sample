import * as React from 'react';
import {View, Text } from 'react-native';
import { NavigationContainer, useNavigation, DrawerActions } from '@react-navigation/native';
import { StatusBar } from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome5';

import {Home as HomeScreen} from '../home-component/home.component';
// import {Profile as ProfileScreen} from '../profile-component/profile.component';
// import {About as AboutScreen} from '../about-component/about.component';

import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

type RootStackParamList = {
    Home: {sort: 'latest' | 'top'} | undefined,
    Details: undefined,
    Profile: { userId: string },
    About: undefined
}

const Tab = createBottomTabNavigator<RootStackParamList>();

export const BottomTabsNavigator = () => {
  console.log('BottomTabsNavigator screen called.')
  const navigation = useNavigation();
    return (
            <Tab.Navigator
             screenOptions={({ route }) => ({
                tabBarIcon: ({ focused, color, size }) => {
                    let iconName;
                      if (route.name === 'Home') {
                        iconName = <Icon name="newspaper" size={20} />;
                      } else if (route.name === 'Profile') {
                        iconName = <Icon name="id-badge" size={20} />;
                      } else if (route.name === 'About') {
                        iconName = <Icon name="info-circle" size={20} />;
                      }
                  return (
                    <View style={{  width: 26, height: 26, paddingBottom: 3}}>
                      {iconName}
                    </View>
                  );
                }
              })}
        
              tabBarOptions={{
                activeTintColor: 'blue',
                inactiveTintColor: 'gray',
                style: {
                  borderTopWidth: 1,
                  paddingTop: 5,
                }
              }}
              >
                <Tab.Screen name="Home" component={HomeScreen} />
                {/* <Tab.Screen name="Profile" component={ProfileScreen} initialParams={{ userId: "me" }} />
                <Tab.Screen name="About" component={AboutScreen} /> */}
            </Tab.Navigator>
    );
}

const styles = {  
    container: {
      flex: 1,
      backgroundColor: 'white',
      width: '100%',
    },
  }