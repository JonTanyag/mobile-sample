import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import Details from '../details-component/details.component';

import Login from '../login-component/login.component';
import { BottomTabsNavigator as BottomTabs } from './bottom.tab.component';

type RootStackParamList = {
    Login: undefined,
    Home: { sort: 'latest' | 'top' } | undefined,
    Details: undefined,
    Profile: { userId: string },
    About: undefined
}

const Stack = createStackNavigator<RootStackParamList>();


export const AppContainer = () => {
    console.log('AppContainer.tsx called.')
    return (
        <Stack.Navigator >
            <Stack.Screen options={{ headerShown: false }} name="Login" component={Login} />
            <Stack.Screen name="Home" component={BottomTabs} />
            <Stack.Screen options={{ headerShown: false }} name="Details" component={Details} />
        </Stack.Navigator>
    );
}
