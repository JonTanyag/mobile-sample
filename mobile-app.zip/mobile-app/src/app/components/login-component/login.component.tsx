import React, {Component} from 'react';
import { View, Image, TextInput, Text, TouchableOpacity, Button, StyleSheet, StyleProp, ViewStyle } from 'react-native';


import { $navigate } from '../../services/navigation.service';

const Login: React.FC = () => {

    return (
        <View style={styles.container}>
                <View style={{ margin: 10 }}>
                    <Image
                        style={{ height: 100, width: 110 }}
                        source={require('../../assets/logo.png')}>
                    </Image>
                </View>
                <View style={{ height: 250 }}>
                    <TextInput
                        //value={this.state.emailaddress}
                        //onChangeText={(emailaddress) => this.setState({ emailaddress, isEmailVaild: true })}
                        //onFocus={() => this._onFocusEmail.bind(this)}
                        placeholder={'Email Address'}
                        style={styles.input}
                    />
                    {/* {
                        !this.state.isEmailVaild &&
                        <Text style={{color: 'red', fontSize: 10 }}>This field is required.</Text>
                    } */}

                    <TextInput
                        // selectionColor={colors.DODGER_BLUE}
                        //value={this.state.password}
                        //onChangeText={(password) => this.setState({ password, isPasswordValid: true })}
                        //onFocus={() => this._onFocusPassword.bind(this)}
                        placeholder={'Password'}
                        secureTextEntry={true}
                        style={styles.input}
                    />
                    {/* {
                        !this.state.isPasswordValid &&
                        <Text style={{color: 'red', fontSize: 10}}>This field is required.</Text>
                    } */}
                    

                    <TouchableOpacity
                        style={{ margin: 5 }}
                        onPress={() => console.log('Register')}>
                        <Text
                            style={{ margin: 5, color: 'blue' }}>Not a member? Signup Now</Text>
                    </TouchableOpacity>
                    <View style={{ flexDirection: 'column', alignContent: "space-around" }}>
                        <Button
                            title={'Login'}
                            style={styles.input as StyleProp<ViewStyle>}
                            onPress={() => $navigate('Home')}
                        />
                    </View>
                </View>
                <View style={styles.footer}>
                    <Text style={{ fontSize: 10 }}>JMTi</Text>
                    <Text style={{ fontSize: 10 }}>Copyright: 2020</Text>
                </View>
                {/* {
                    this.state.isSaving &&
                    // <Spinner
                    //     visible={this.state.isSaving}
                    //     textContent={'Logging in'}
                    //     textStyle={styles.spinnerTextStyle}
                    // />
                } */}
            </View>
    )
}

const styles = StyleSheet.create({
    containerStyle: {
        borderWidth: 1,
        borderRadius: 2,
        borderColor: '#ddd',
        borderBottomWidth: 0,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.8,
        shadowRadius: 2,
        elevation: 1,
        marginLeft: 5,
        marginRight: 5,
        marginTop: 10,
    },
    container: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'white'
    },
    spinnerTextStyle: {
        fontSize: 10,
        fontStyle: 'italic',
        color: 'rgba(0,0,0,0.1)'
    },
    input: {
        width: 200,
        height: 40,
        borderBottomWidth: StyleSheet.hairlineWidth,
        borderColor: 'silver', // color.SILVER,
        marginBottom: 20,
    },
    inputFacebook: {
        width: 200,
        height: 40,
        borderBottomWidth: StyleSheet.hairlineWidth,
        borderColor: 'silver', // color.SILVER,
        marginBottom: 20,
        margin: 5,
        backgroundColor: 'blue'
    },
    inputGoogle: {
        width: 200,
        height: 40,
        borderBottomWidth: StyleSheet.hairlineWidth,
        borderColor: 'silver', // color.SILVER,
        marginBottom: 20,
        margin: 5,
        backgroundColor: 'red'
    },
    footer: {
        fontSize: 5,
        textShadowColor: 'grey',
        color: 'grey',
        position: 'absolute',
        bottom: 0,
        alignItems: 'center',
        justifyContent: 'center',
        fontFamily: 'Cochin'
    }
});

export default Login;