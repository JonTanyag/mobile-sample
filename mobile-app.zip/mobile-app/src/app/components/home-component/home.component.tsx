import React, { useState } from 'react';
import { FAB } from 'react-native-paper';
import { SafeAreaView, ScrollView, RefreshControl } from 'react-native';

import { ThingsDataComponent } from './things.data.component';


export const Home: React.FC = () => {
    const [refreshing, setRefreshing] = useState(false);

    const onRefresh = React.useCallback(() => {
        setRefreshing(true);

        //   wait(2000).then(() => setRefreshing(false));
    }, []);

    

    return (
        <SafeAreaView>
            <ScrollView refreshControl={
                <RefreshControl
                    refreshing={refreshing}
                    onRefresh={onRefresh} />
            }>
                <ThingsDataComponent />
            </ScrollView>
            <FAB style={styles.fab}
                large
                icon={require('../../assets/edit.png')}
                >
            </FAB>
        </SafeAreaView>
    )
}

const styles = {
    fab: {
      position: 'absolute',
      margin: 25,
      right: 0,
      bottom: 0,
      // borderColor: 'black',
      // borderWidth: 1,
    }
  }
