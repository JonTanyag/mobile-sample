import React, { useState } from 'react';
import { View, Text, Image, TouchableOpacity, StyleProp, ViewStyle } from 'react-native';

import { $navigate } from '../../services/navigation.service';
import { ThingsData } from '../../seed/things.data';

const thingsData = ThingsData


export const ThingsDataComponent = () => {
    console.log('ThingsComponent called.')
    const [things, setThings] = useState(thingsData);

    return things.map(item => {
        return (
            <View style={styles.containerStyle as StyleProp<ViewStyle>} key={item.id}>
                <View style={styles.innerContainerStyle as StyleProp<ViewStyle>}>
                    <TouchableOpacity>
                        <View style={styles.leftContainer as StyleProp<ViewStyle>}>
                            <Image style={styles.logo} source={item.image}/>
                        </View>
                    </TouchableOpacity>
                    <TouchableOpacity
                        style={styles.buttonStyle as StyleProp<ViewStyle>}
                        onPress={() => $navigate('Details', { itemId: item.details, image: item.image })}>
                        <View style={styles.headerContentStyle as StyleProp<ViewStyle>}>
                            <Text>{item.name}</Text>
                            <Text>{item.location}</Text>
                            <Text>{item.details}</Text>
                        </View>
                    </TouchableOpacity>
                </View>
            </View>
        )
    });
}

const styles = {
    containerStyle: {
        borderColor: '#ddd',
        borderBottomWidth: 0,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 2,
        marginLeft: 5,
        marginRight: 5,
        marginTop: 10,
        width:'98%'
    },
    innerContainerStyle: {
        borderBottomWidth: 1,
        padding: 5,
        backgroundColor: '#fff',
        flexDirection: 'column',
        justifyContent: 'flex-start',
        borderColor: '#ddd',
        position: 'relative'
      },
    container: {
        flex: 1,
        backgroundColor: 'white',
        width: '100%',
        flexDirection: 'column',
    },
    buttonStyle: {
        flex: 1,
        alignSelf: 'stretch',
        backgroundColor: '#fff',
        borderColor: '#007aff',
        marginLeft: 5,
        marginRight: 5
    },
    headerContentStyle: {
      flexDirection: 'column',
      justifyContent: 'space-between'
    },
    leftContainer: {
        marginTop: 5,
        flexDirection: 'row',
        justifyContent: 'flex-start',
        width: 100,
    },
    logo: {
        height: 45,
        width: 45,
        borderRadius: 100 / 2,
        backgroundColor: 'grey'
    }
}
