import React, { Component } from 'react';
import { View, Text, Button, StyleProp, ViewStyle, Image, Dimensions } from 'react-native';

import {$navigate, $navigateBack} from '../../services/navigation.service';

interface Props {
    onLoad?: () => void;
    itemId?: string;
    image?: {};
}

const Add: React.FC<Props> = ({route}: any) => {
    console.log('Details screen called.')
        return (
            <View style={styles.container as StyleProp<ViewStyle>}>
                
            </View>

        )
    
}

const styles = {  
    container: {
      flex: 1,
      backgroundColor: 'white',
      width: '100%',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center'
    },
}
// export default Details;