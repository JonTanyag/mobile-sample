import {createRef} from 'react';
import {StackActions} from '@react-navigation/native';


export const isMountedRef = createRef<any>();

export const navigationRef = createRef<any>();

export const $navigationState = navigationRef.current;

export function $navigate(name: string, params?: any){
    navigationRef.current?.navigate(name, params);
}

export function $navigateBack() {
    navigationRef.current?.goBack();
}

export function $navigateReset(){
    navigationRef.current?.dispatch(StackActions.popToTop());
}

export function $navigateDispatch(action: any) {
    navigationRef.current?.dispatch(action);
}
