export const ThingsData = [{
    id: "1",
    name: "Car Key",
    date: 'Feb 19, 2020',
    location: 'cabinet',
    details: 'Cabinet located beside front door',
    image: require('../assets/car-keys.jpg')
},
{
    id: "2",
    name: "Government IDs",
    date: 'Feb 19, 2020',
    location: 'Cabinet',
    details: 'harcase wallet inside cabinet in my bedroom',
    image: require('../assets/national-id-1.jpg')
},
{
    id: "3",
    name: "Small flash light",
    date: 'Feb 19, 2020',
    location: 'TV table',
    details: 'right door of TV table cabinet',
    image: require('../assets/flashlight.jpg')
},
{
    id: "4",
    name: "charger cable spare",
    date: 'Feb 19, 2020',
    location: 'TV Table',
    details: 'hard case left door tv cable cabinet',
    image: require('../assets/car-keys.jpg')
},

]